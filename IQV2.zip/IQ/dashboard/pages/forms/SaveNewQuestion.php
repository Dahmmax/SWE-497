<?php
include('../../../app/database/connect.php');
session_start();

$QuestionHead = $_POST["QuestionHead"];
$Score = $_POST["Score"];
$iscorrect = $_POST["iscorrect"];
$QuizId = $_POST["QuizId"];
$userid = $_SESSION['id'];
///
$AnswerA = $_POST["AnswerA"];
$AnswerB = $_POST["AnswerB"];
$AnswerC = $_POST["AnswerC"];
$AnswerD = $_POST["AnswerD"];




$sql = "INSERT INTO question (Head, Score, CorrectAnswer,QuizId, UserId) VALUES('$QuestionHead','$Score','$iscorrect','$QuizId','$userid')";
if ($conn->query($sql) === TRUE) {
    echo "DATA updated";

   
    $query = "SELECT MAX(Question_Id) FROM `question` WHERE QuizId ='$QuizId' AND UserId='$userid ' ";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_row($result);
    $maxid= $row[0];
//
$sql = "INSERT INTO answers (Head,Question_id)
VALUES ('$AnswerA', '$maxid');";
$sql .= "INSERT INTO answers (Head,Question_id)
VALUES ('$AnswerB', '$maxid');";
$sql .= "INSERT INTO answers (Head,Question_id)
VALUES ('$AnswerC', '$maxid');";
$sql .= "INSERT INTO answers (Head,Question_id)
VALUES ('$AnswerD', '$maxid');";

if ($conn->multi_query($sql) === TRUE) {
  echo "New ANSWERS created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
}
?>